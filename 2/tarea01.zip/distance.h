/*
	Header of main program
	with function definitions.
*/

#include <stdio.h>


float convert_to_miles(float);

int load_value(float *);